# Zendesk View Descriptions Directory (Sidebar App)

A native Zendesk Apps Framework (ZAF v2) sidebar application that displays the **descriptions, purpose, SOP guidelines, and criteria** of all active views in Zendesk Support.

---

## 💡 Why This App?

When administrators create Views in Zendesk (**Admin Center > Workspaces > Agent tools > Views**), they can define detailed descriptions explaining:
- What tickets belong in the view.
- Standard operating procedures (SOPs) and response SLAs.
- Routing rules and escalation criteria.

However, **Zendesk's default agent interface only shows the view title and ticket count**—it never displays the description to agents!

This app brings view descriptions directly to the agent's fingertips:
1. **Ticket Sidebar (`ticket_sidebar`)**: Agents working on a ticket can see all view descriptions and instantly know which view a ticket belongs to or where to route it.
2. **New Ticket Sidebar (`new_ticket_sidebar`)**: Guidance when drafting and triaging new tickets.
3. **Left Navigation Bar (`nav_bar`)**: Side drawer alongside the Views menu for quick reference.
4. **Top Bar (`top_bar`)**: Quick lookup popup from anywhere in Zendesk.

---

## ✨ Features

- 📋 **View Descriptions at a Glance**: Prominently shows the description of every active view with clean Zendesk Garden typography and formatting.
- 🎯 **Smart Ticket Matching**: When viewing a ticket in `ticket_sidebar`, the app automatically checks the open ticket (`status`, `priority`, `type`, `group`, `tags`) against view criteria and flags matching views with a green `✓ Matches Ticket` badge.
- 🔍 **Real-Time Search**: Search through views by title, description text, or view ID with instant keyword highlighting (`<mark>`).
- 🏷️ **Filter Pills**: Quickly filter by:
  - **All Views**
  - **Matches Ticket** (active in ticket sidebar)
  - **With Description**
  - **No Description** (highlights views that need admin documentation)
- ⚙️ **View Criteria Inspector**: Expand any view to see its exact configuration:
  - *Meet ALL criteria* (e.g., Status is Open, Group is Tier 2 Support)
  - *Meet ANY criteria* (e.g., Priority is Urgent, Tags contain VIP)
  - View ID and last updated timestamp
- 🚀 **One-Click Navigation**: "Go to View" button utilizes native ZAF `client.invoke('routeTo', 'views', viewId)` to immediately switch the agent to that queue.
- 📋 **Copy Details**: Copy view name, ID, and description with one click to paste into ticket notes or Slack/Teams.
- ⚠️ **Missing Description Alert**: If a view lacks a description, displays a subtle notice and a direct link to edit the view in Zendesk Admin Center.
- 🎨 **Zendesk Garden Aesthetic**: Designed to seamlessly blend into Zendesk Support, adhering to official Garden colors, typography, border radius, and contrast standards.
- 🧪 **Offline / Local Preview Mode**: Open `assets/iframe.html` directly in any web browser without needing a live Zendesk instance to test with realistic mock data and ticket simulation.

---

## 📂 Project Structure

```
zendesk-view-descriptions-app/
├── manifest.json              # App configuration, locations, permissions & settings
├── assets/
│   ├── iframe.html            # Main responsive UI
│   ├── style.css              # Zendesk Garden design system styling
│   ├── main.js                # ZAF v2 client logic, REST API fetch, ticket matcher
│   ├── mock-data.js           # Realistic mock views and ticket simulator data
│   ├── logo.png               # App icon (128x128)
│   └── logo-small.png         # App small icon (32x32)
├── translations/
│   └── en.json                # English translation strings and parameter descriptions
├── dist/
│   └── zendesk-view-descriptions-app.zip  # Ready-to-upload package for Zendesk
├── build-zip.py               # Zero-dependency packaging script
├── package.json               # NPM scripts for development and building
└── README.md                  # Documentation
```

---

## 🚀 How to Install in Zendesk

### Step 1: Locate the Zip File
The build script generates a production-ready zip file at:
```
dist/zendesk-view-descriptions-app.zip
```
*(To rebuild at any time, run `python3 build-zip.py`)*

### Step 2: Upload to Zendesk Support
1. Log in to your Zendesk account as an **Administrator**.
2. Click the **Admin Center** gear icon or navigate to:
   `https://YOUR_SUBDOMAIN.zendesk.com/admin/apps-integrations/apps/support-apps`
3. Click **Upload private app** (top right).
4. Enter an **App Name** (e.g., `View Descriptions Directory`).
5. Click **Choose File** and select `dist/zendesk-view-descriptions-app.zip`.
6. Click **Upload**.
7. Review the app parameters:
   - **Show notice for views without descriptions**: Enabled by default.
   - **Enable Smart Ticket Matching**: Enabled by default.
   - **Default Filter View**: `all` (or `matching` / `with_desc`).
8. Click **Install**.

The app is now live! Open any ticket to see it in the right sidebar.

---

## 💻 Local Testing & Preview

You can test and preview the app immediately without uploading to Zendesk:

### Option A: Open directly in Browser
Open `assets/iframe.html` in Chrome, Firefox, Safari, or Edge:
```bash
open assets/iframe.html
```
The app will automatically detect standalone mode, display the **Local Preview banner**, and let you interact with sample views and switch between simulated tickets to test condition matching!

### Option B: Local HTTP Server
Run:
```bash
python3 -m http.server 8080 --directory assets
```
Then visit `http://localhost:8080/iframe.html`.

### Option C: Zendesk CLI (`zcli`)
If you use the official Zendesk CLI:
```bash
zcli apps:server
```
Then append `?zaf=true` to any Zendesk Support ticket URL.

---

## 🔒 Security & Permissions

- **Zero External Calls**: The app does not transmit ticket data or view information to any external server. All API calls use relative paths (`/api/v2/views/active.json`) handled securely via the agent's existing Zendesk session cookie.
- **XSS Prevention**: All view titles, descriptions, and ticket details are escaped before rendering.
- **Permissions**: Requires standard agent view permissions (standard agents can read active views they have access to).

---

## 🛠️ Customization

- **Change Default Locations**: Edit `"location"` in `manifest.json` if you only want the app in `ticket_sidebar` or only in `nav_bar`.
- **Styling**: Tweak CSS variables in `assets/style.css` (e.g., `--zd-color-kale`, `--zd-color-blue`).
- **Additional Match Fields**: Expand `evaluateTicketMatch` in `assets/main.js` to match custom ticket fields.
