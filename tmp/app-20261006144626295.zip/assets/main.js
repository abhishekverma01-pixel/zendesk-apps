/**
 * Zendesk View Descriptions App
 * Framework: Zendesk Apps Framework (ZAF v2)
 */

(function () {
  'use strict';

  // State Management
  const state = {
    isMockMode: false,
    client: null,
    accountSubdomain: '',
    location: 'ticket_sidebar',
    views: [],
    currentTicket: null,
    activeFilter: 'all',
    searchQuery: '',
    expandedCriteria: new Set(),
    settings: {
      showMissingDescriptionNotice: true,
      enableTicketMatching: true,
      defaultFilter: 'all'
    }
  };

  // DOM Elements
  const elements = {
    appContainer: document.getElementById('app'),
    viewCountBadge: document.getElementById('view-count-badge'),
    btnRefresh: document.getElementById('btn-refresh'),
    devBanner: document.getElementById('dev-banner'),
    mockTicketSelect: document.getElementById('mock-ticket-select'),
    ticketContextBar: document.getElementById('ticket-context-bar'),
    ticketContextDetails: document.getElementById('ticket-context-details'),
    ticketMatchCount: document.getElementById('ticket-match-count'),
    searchInput: document.getElementById('search-input'),
    searchClearBtn: document.getElementById('search-clear-btn'),
    filterPills: document.getElementById('filter-pills'),
    pillMatching: document.getElementById('pill-matching'),
    countMatching: document.getElementById('count-matching'),
    countWithDesc: document.getElementById('count-with-desc'),
    countMissingDesc: document.getElementById('count-missing-desc'),
    mainContent: document.getElementById('main-content'),
    loadingState: document.getElementById('loading-state'),
    errorState: document.getElementById('error-state'),
    errorMessage: document.getElementById('error-message'),
    btnRetry: document.getElementById('btn-retry'),
    emptyState: document.getElementById('empty-state'),
    btnResetFilters: document.getElementById('btn-reset-filters'),
    viewsList: document.getElementById('views-list'),
    footerStatus: document.getElementById('footer-status')
  };

  /**
   * Helper: Escape HTML to prevent XSS
   */
  function escapeHtml(text) {
    if (!text) return '';
    return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  /**
   * Helper: Highlight query terms in text
   */
  function highlightText(text, query) {
    const escaped = escapeHtml(text);
    if (!query || !query.trim()) return escaped;
    const cleanQuery = query.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${cleanQuery})`, 'gi');
    return escaped.replace(regex, '<mark>$1</mark>');
  }

  /**
   * Helper: Request dynamic resize in Zendesk iframe
   */
  function resizeApp() {
    if (state.client && typeof state.client.invoke === 'function') {
      setTimeout(() => {
        const height = Math.max(380, document.body.scrollHeight + 15);
        state.client.invoke('resize', { width: '100%', height: `${height}px` }).catch(() => {});
      }, 50);
    }
  }

  /**
   * Human-readable condition formatter
   */
  function formatCondition(cond) {
    if (!cond) return '';
    const fieldMap = {
      'status': 'Status',
      'priority': 'Priority',
      'type': 'Ticket Type',
      'group_id': 'Group',
      'assignee_id': 'Assignee',
      'current_tags': 'Tags',
      'ticket_form_id': 'Form'
    };

    const opMap = {
      'is': 'is',
      'is_not': 'is not',
      'less_than': 'is less than',
      'greater_than': 'is greater than',
      'includes': 'contains',
      'not_includes': 'does not contain'
    };

    const field = fieldMap[cond.field] || cond.field;
    const operator = opMap[cond.operator] || cond.operator;
    let value = cond.value;

    if (value === null || value === '' || value === undefined) {
      value = 'Unassigned';
    } else if (value === 'current_user') {
      value = 'Current User';
    }

    return `${field} ${operator} <strong>${escapeHtml(value)}</strong>`;
  }

  /**
   * Evaluate if a ticket satisfies a view's conditions
   */
  function evaluateTicketMatch(view, ticket) {
    if (!ticket || !view.conditions) return false;

    const statusOrder = ['new', 'open', 'pending', 'hold', 'solved', 'closed'];
    const priorityOrder = ['low', 'normal', 'high', 'urgent'];

    function checkCond(c) {
      if (!c) return true;
      const field = c.field;
      const op = c.operator;
      const val = c.value;

      if (field === 'status') {
        const ticketStatus = (ticket.status || '').toLowerCase();
        if (op === 'is') return ticketStatus === (val || '').toLowerCase();
        if (op === 'is_not') return ticketStatus !== (val || '').toLowerCase();
        if (op === 'less_than') {
          const tIdx = statusOrder.indexOf(ticketStatus);
          const vIdx = statusOrder.indexOf((val || '').toLowerCase());
          return tIdx !== -1 && vIdx !== -1 && tIdx < vIdx;
        }
        if (op === 'greater_than') {
          const tIdx = statusOrder.indexOf(ticketStatus);
          const vIdx = statusOrder.indexOf((val || '').toLowerCase());
          return tIdx !== -1 && vIdx !== -1 && tIdx > vIdx;
        }
      }

      if (field === 'priority') {
        const ticketPriority = (ticket.priority || 'normal').toLowerCase();
        if (op === 'is') return ticketPriority === (val || '').toLowerCase();
        if (op === 'is_not') return ticketPriority !== (val || '').toLowerCase();
        if (op === 'less_than') {
          const tIdx = priorityOrder.indexOf(ticketPriority);
          const vIdx = priorityOrder.indexOf((val || '').toLowerCase());
          return tIdx !== -1 && vIdx !== -1 && tIdx < vIdx;
        }
        if (op === 'greater_than') {
          const tIdx = priorityOrder.indexOf(ticketPriority);
          const vIdx = priorityOrder.indexOf((val || '').toLowerCase());
          return tIdx !== -1 && vIdx !== -1 && tIdx > vIdx;
        }
      }

      if (field === 'type') {
        const ticketType = (ticket.type || '').toLowerCase();
        if (op === 'is') return ticketType === (val || '').toLowerCase();
        if (op === 'is_not') return ticketType !== (val || '').toLowerCase();
      }

      if (field === 'assignee_id') {
        if (val === null || val === 'null' || val === '') {
          return !ticket.assignee || !ticket.assignee.id;
        }
        if (val === 'current_user') {
          return ticket.assignee && ticket.assignee.isCurrentUser;
        }
      }

      if (field === 'current_tags') {
        const tags = Array.isArray(ticket.tags) ? ticket.tags.map(t => String(t).toLowerCase()) : [];
        const targetVal = String(val || '').toLowerCase();
        if (op === 'includes') return tags.includes(targetVal);
        if (op === 'not_includes') return !tags.includes(targetVal);
      }

      // Default to permissive if field cannot be determined
      return true;
    }

    const allConds = view.conditions.all || [];
    const anyConds = view.conditions.any || [];

    // All conditions must pass
    const allPassed = allConds.every(checkCond);
    if (!allPassed) return false;

    // Any condition (if specified, at least one must pass)
    if (anyConds.length > 0) {
      const anyPassed = anyConds.some(checkCond);
      if (!anyPassed) return false;
    }

    return true;
  }

  /**
   * Update matching status on all views
   */
  function evaluateAllViewsForTicket() {
    let matchCount = 0;
    state.views.forEach(view => {
      view._matchesTicket = state.currentTicket ? evaluateTicketMatch(view, state.currentTicket) : false;
      if (view._matchesTicket) matchCount++;
    });

    if (elements.countMatching) {
      elements.countMatching.textContent = matchCount;
    }

    if (elements.ticketMatchCount) {
      elements.ticketMatchCount.textContent = `${matchCount} Views Match`;
    }

    if (state.currentTicket && state.settings.enableTicketMatching) {
      elements.pillMatching.classList.remove('hidden');
    } else {
      elements.pillMatching.classList.add('hidden');
    }
  }

  /**
   * Filter and search views based on current state
   */
  function getFilteredViews() {
    const query = state.searchQuery.trim().toLowerCase();

    return state.views.filter(view => {
      // 1. Filter pill check
      if (state.activeFilter === 'matching' && !view._matchesTicket) {
        return false;
      }
      if (state.activeFilter === 'with_desc' && (!view.description || !view.description.trim())) {
        return false;
      }
      if (state.activeFilter === 'missing_desc' && (view.description && view.description.trim())) {
        return false;
      }

      // 2. Search query check
      if (query) {
        const titleMatch = (view.title || '').toLowerCase().includes(query);
        const descMatch = (view.description || '').toLowerCase().includes(query);
        const idMatch = String(view.id).includes(query);
        return titleMatch || descMatch || idMatch;
      }

      return true;
    });
  }

  /**
   * Update count badges
   */
  function updateCounts() {
    const total = state.views.length;
    const withDesc = state.views.filter(v => v.description && v.description.trim()).length;
    const missingDesc = total - withDesc;

    elements.viewCountBadge.textContent = `${total} views`;
    elements.countWithDesc.textContent = withDesc;
    elements.countMissingDesc.textContent = missingDesc;
  }

  /**
   * Render the views list
   */
  function renderViews() {
    elements.loadingState.classList.add('hidden');
    elements.errorState.classList.add('hidden');

    const filtered = getFilteredViews();

    if (filtered.length === 0) {
      elements.viewsList.innerHTML = '';
      elements.emptyState.classList.remove('hidden');
      resizeApp();
      return;
    }

    elements.emptyState.classList.add('hidden');

    const html = filtered.map(view => {
      const hasDescription = !!(view.description && view.description.trim());
      const isExpanded = state.expandedCriteria.has(view.id);
      const isMatching = !!view._matchesTicket;

      let cardClasses = ['view-card'];
      if (isMatching) cardClasses.push('matches-ticket');
      if (hasDescription) cardClasses.push('has-description');
      else cardClasses.push('missing-description');

      // Admin URL for direct editing
      const adminUrl = state.accountSubdomain 
        ? `https://${state.accountSubdomain}.zendesk.com/admin/workspaces/agent-tools/views/${view.id}`
        : `/admin/workspaces/agent-tools/views/${view.id}`;

      // Description section
      let descHtml = '';
      if (hasDescription) {
        descHtml = `
          <div class="view-desc-box">
            <div class="view-description">${highlightText(view.description, state.searchQuery)}</div>
          </div>
        `;
      } else if (state.settings.showMissingDescriptionNotice) {
        descHtml = `
          <div class="view-no-desc-box">
            <span class="view-no-desc-text">⚠️ No description provided for this view.</span>
            <a href="${adminUrl}" target="_blank" rel="noopener noreferrer" class="btn-link" title="Open in Admin Center">Edit in Admin &rarr;</a>
          </div>
        `;
      }

      // Criteria details section
      let criteriaHtml = '';
      if (isExpanded) {
        const allConds = (view.conditions && view.conditions.all) || [];
        const anyConds = (view.conditions && view.conditions.any) || [];

        criteriaHtml = `
          <div class="criteria-drawer" id="criteria-${view.id}">
            <div class="criteria-title">View Criteria & Rules</div>
            
            ${allConds.length > 0 ? `
              <div style="font-weight:600; margin-top:2px;">Meet ALL criteria:</div>
              <ul class="criteria-list">
                ${allConds.map(c => `
                  <li class="criteria-item">
                    <span class="criteria-bullet">&bull;</span>
                    <span>${formatCondition(c)}</span>
                  </li>
                `).join('')}
              </ul>
            ` : ''}

            ${anyConds.length > 0 ? `
              <div style="font-weight:600; margin-top:4px;">Meet ANY criteria:</div>
              <ul class="criteria-list">
                ${anyConds.map(c => `
                  <li class="criteria-item">
                    <span class="criteria-bullet">&bull;</span>
                    <span>${formatCondition(c)}</span>
                  </li>
                `).join('')}
              </ul>
            ` : ''}

            ${allConds.length === 0 && anyConds.length === 0 ? '<p style="color:#68737d;">No specific conditions configured.</p>' : ''}

            <div class="criteria-meta">
              <span>View ID: <strong>#${view.id}</strong></span>
              <span>Updated: ${new Date(view.updated_at || Date.now()).toLocaleDateString()}</span>
            </div>
          </div>
        `;
      }

      return `
        <article class="${cardClasses.join(' ')}" data-view-id="${view.id}">
          <div class="card-top">
            <div class="view-title-group">
              <h2 class="view-title">${highlightText(view.title, state.searchQuery)}</h2>
            </div>
            <div class="card-badges">
              ${isMatching ? '<span class="badge badge-success">&#10003; Matches Ticket</span>' : ''}
              ${view.restriction && view.restriction.type === 'Group' ? '<span class="badge badge-purple">Group Restricted</span>' : '<span class="badge badge-neutral">Shared</span>'}
            </div>
          </div>

          ${descHtml}

          <div class="card-actions">
            <div class="card-actions-left">
              <button class="btn btn-primary btn-route-view" data-view-id="${view.id}" title="Navigate to this view in Zendesk">
                <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M5 12h14M12 5l7 7-7 7"/>
                </svg>
                Go to View
              </button>
              <button class="btn-link btn-toggle-criteria" data-view-id="${view.id}">
                ${isExpanded ? 'Hide Criteria &minus;' : 'View Criteria &plus;'}
              </button>
            </div>
            <div class="card-actions-right">
              <button class="btn-text-icon btn-copy-view" data-view-id="${view.id}" title="Copy description">
                <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
                Copy
              </button>
            </div>
          </div>

          ${criteriaHtml}
        </article>
      `;
    }).join('');

    elements.viewsList.innerHTML = html;
    resizeApp();
  }

  /**
   * Route agent directly to the view
   */
  function navigateToView(viewId) {
    if (state.client && typeof state.client.invoke === 'function') {
      state.client.invoke('routeTo', 'views', viewId).then(() => {
        elements.footerStatus.textContent = `Navigated to view #${viewId}`;
      }).catch(err => {
        console.warn('routeTo error, opening fallback URL:', err);
        window.open(`/agent/filters/${viewId}`, '_blank');
      });
    } else {
      // In local preview mode
      alert(`[Preview Mode] Would navigate to Zendesk View #${viewId}`);
    }
  }

  /**
   * Copy view details to clipboard
   */
  function copyViewDetails(viewId, btnElement) {
    const view = state.views.find(v => String(v.id) === String(viewId));
    if (!view) return;

    const textToCopy = `View: ${view.title}\nID: ${view.id}\nDescription: ${view.description || '(No description)'}`;
    navigator.clipboard.writeText(textToCopy).then(() => {
      const originalText = btnElement.innerHTML;
      btnElement.innerHTML = `&#10003; Copied!`;
      setTimeout(() => {
        btnElement.innerHTML = originalText;
      }, 1500);
    }).catch(() => {
      prompt('Copy view info:', textToCopy);
    });
  }

  /**
   * Fetch active views from Zendesk API
   */
  function fetchViews() {
    elements.loadingState.classList.remove('hidden');
    elements.errorState.classList.add('hidden');
    elements.emptyState.classList.add('hidden');
    elements.viewsList.innerHTML = '';
    elements.btnRefresh.querySelector('.icon-refresh').style.transform = 'rotate(360deg)';

    if (state.isMockMode) {
      setTimeout(() => {
        state.views = window.MOCK_VIEWS_DATA ? window.MOCK_VIEWS_DATA.views : [];
        evaluateAllViewsForTicket();
        updateCounts();
        renderViews();
        elements.footerStatus.textContent = `Loaded ${state.views.length} views (Local Mock)`;
      }, 350);
      return;
    }

    // Call Zendesk REST API
    state.client.request({
      url: '/api/v2/views/active.json',
      type: 'GET',
      dataType: 'json'
    }).then(response => {
      state.views = response.views || [];
      evaluateAllViewsForTicket();
      updateCounts();
      renderViews();
      elements.footerStatus.textContent = `Synced ${state.views.length} active views`;
    }).catch(error => {
      console.error('Error fetching views from Zendesk API:', error);
      elements.loadingState.classList.add('hidden');
      elements.errorState.classList.remove('hidden');
      elements.errorMessage.textContent = error.message || 'Unable to retrieve views. Please check agent permissions.';
    });
  }

  /**
   * Load current ticket details in ticket_sidebar
   */
  function loadTicketDetails() {
    if (state.isMockMode) {
      setupMockTicketSelector();
      return;
    }

    if (!state.client || (state.location !== 'ticket_sidebar' && state.location !== 'new_ticket_sidebar')) {
      elements.ticketContextBar.classList.add('hidden');
      return;
    }

    state.client.get([
      'ticket.id',
      'ticket.subject',
      'ticket.status',
      'ticket.priority',
      'ticket.type',
      'ticket.tags',
      'ticket.group',
      'ticket.assignee',
      'currentUser.id'
    ]).then(data => {
      const ticketId = data['ticket.id'];
      if (!ticketId) {
        elements.ticketContextBar.classList.add('hidden');
        return;
      }

      state.currentTicket = {
        id: ticketId,
        subject: data['ticket.subject'] || '',
        status: data['ticket.status'] || '',
        priority: data['ticket.priority'] || 'normal',
        type: data['ticket.type'] || '',
        tags: data['ticket.tags'] || [],
        group: data['ticket.group'],
        assignee: data['ticket.assignee']
      };

      // Show ticket bar
      elements.ticketContextBar.classList.remove('hidden');
      elements.ticketContextDetails.textContent = `#${ticketId} (${state.currentTicket.status.toUpperCase()})`;

      evaluateAllViewsForTicket();
      renderViews();
    }).catch(err => {
      console.warn('Could not read ticket context:', err);
    });

    // Listen for changes on the ticket
    state.client.on('ticket.status.changed', () => loadTicketDetails());
    state.client.on('ticket.priority.changed', () => loadTicketDetails());
    state.client.on('ticket.tags.changed', () => loadTicketDetails());
  }

  /**
   * Setup interactive mock ticket selector for local testing
   */
  function setupMockTicketSelector() {
    elements.devBanner.classList.remove('hidden');
    elements.ticketContextBar.classList.remove('hidden');

    const tickets = window.MOCK_TICKETS || [];
    elements.mockTicketSelect.innerHTML = tickets.map((t, idx) => `
      <option value="${idx}">#${t.id}: ${t.priority.toUpperCase()} - ${escapeHtml(t.subject.substring(0, 30))}...</option>
    `).join('');

    function applySelectedMockTicket() {
      const idx = elements.mockTicketSelect.value;
      const selected = tickets[idx];
      state.currentTicket = selected;
      elements.ticketContextDetails.textContent = `#${selected.id} (${selected.status.toUpperCase()} / ${selected.priority.toUpperCase()})`;
      evaluateAllViewsForTicket();
      renderViews();
    }

    elements.mockTicketSelect.addEventListener('change', applySelectedMockTicket);
    applySelectedMockTicket();
  }

  /**
   * Bind event listeners
   */
  function bindEvents() {
    // Search input
    let debounceTimer;
    elements.searchInput.addEventListener('input', (e) => {
      clearTimeout(debounceTimer);
      state.searchQuery = e.target.value;
      if (state.searchQuery) {
        elements.searchClearBtn.classList.remove('hidden');
      } else {
        elements.searchClearBtn.classList.add('hidden');
      }
      debounceTimer = setTimeout(renderViews, 120);
    });

    // Clear search
    elements.searchClearBtn.addEventListener('click', () => {
      elements.searchInput.value = '';
      state.searchQuery = '';
      elements.searchClearBtn.classList.add('hidden');
      renderViews();
    });

    // Filter pills
    elements.filterPills.addEventListener('click', (e) => {
      const pill = e.target.closest('.filter-pill');
      if (!pill) return;

      document.querySelectorAll('.filter-pill').forEach(p => {
        p.classList.remove('active');
        p.setAttribute('aria-selected', 'false');
      });

      pill.classList.add('active');
      pill.setAttribute('aria-selected', 'true');
      state.activeFilter = pill.getAttribute('data-filter') || 'all';
      renderViews();
    });

    // Delegated click events in views list
    elements.viewsList.addEventListener('click', (e) => {
      // 1. "Go to View"
      const routeBtn = e.target.closest('.btn-route-view');
      if (routeBtn) {
        const viewId = routeBtn.getAttribute('data-view-id');
        navigateToView(viewId);
        return;
      }

      // 2. Toggle criteria drawer
      const toggleBtn = e.target.closest('.btn-toggle-criteria');
      if (toggleBtn) {
        const viewId = parseInt(toggleBtn.getAttribute('data-view-id'), 10);
        if (state.expandedCriteria.has(viewId)) {
          state.expandedCriteria.delete(viewId);
        } else {
          state.expandedCriteria.add(viewId);
        }
        renderViews();
        return;
      }

      // 3. Copy view
      const copyBtn = e.target.closest('.btn-copy-view');
      if (copyBtn) {
        const viewId = copyBtn.getAttribute('data-view-id');
        copyViewDetails(viewId, copyBtn);
        return;
      }
    });

    // Refresh button
    elements.btnRefresh.addEventListener('click', () => {
      fetchViews();
    });

    // Retry button on error
    elements.btnRetry.addEventListener('click', () => {
      fetchViews();
    });

    // Reset filters on empty state
    elements.btnResetFilters.addEventListener('click', () => {
      elements.searchInput.value = '';
      state.searchQuery = '';
      elements.searchClearBtn.classList.add('hidden');

      document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
      const allPill = document.querySelector('.filter-pill[data-filter="all"]');
      if (allPill) allPill.classList.add('active');
      state.activeFilter = 'all';

      renderViews();
    });
  }

  /**
   * App Initializer
   */
  function initApp() {
    bindEvents();

    const isRunningInsideZendesk = typeof window.ZAFClient !== 'undefined' && window.self !== window.top;

    if (!isRunningInsideZendesk) {
      console.log('Running in Standalone / Preview Mode with mock data');
      state.isMockMode = true;
      state.location = 'ticket_sidebar';
      setupMockTicketSelector();
      fetchViews();
      return;
    }

    try {
      state.client = window.ZAFClient.init();

      // Read context
      state.client.context().then(context => {
        state.location = context.location || 'ticket_sidebar';
        if (context.account && context.account.subdomain) {
          state.accountSubdomain = context.account.subdomain;
        }

        // Read app settings/parameters
        state.client.metadata().then(metadata => {
          if (metadata && metadata.settings) {
            Object.assign(state.settings, metadata.settings);
            if (state.settings.defaultFilter) {
              state.activeFilter = state.settings.defaultFilter;
            }
          }
          loadTicketDetails();
          fetchViews();
        }).catch(() => {
          loadTicketDetails();
          fetchViews();
        });
      }).catch(err => {
        console.warn('context() error, fallback to defaults:', err);
        loadTicketDetails();
        fetchViews();
      });

    } catch (e) {
      console.error('Failed to initialize ZAFClient:', e);
      state.isMockMode = true;
      fetchViews();
    }
  }

  // Launch when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
  } else {
    initApp();
  }

})();
