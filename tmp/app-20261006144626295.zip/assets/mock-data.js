/**
 * Mock data for Zendesk View Descriptions App
 * Used when running standalone outside of Zendesk iframe or in test environments.
 */
window.MOCK_VIEWS_DATA = {
  "views": [
    {
      "id": 1001,
      "title": "🔥 Urgent & P1 Incidents",
      "raw_title": "Urgent & P1 Incidents",
      "description": "High-priority customer incidents requiring rapid response within 15 minutes. Escalate to Engineering On-Call if unassigned after 30 minutes.\n\nSLA: 15-minute first reply, hourly status updates.",
      "active": true,
      "updated_at": "2026-10-01T12:00:00Z",
      "restriction": null,
      "conditions": {
        "all": [
          { "field": "status", "operator": "less_than", "value": "solved" },
          { "field": "priority", "operator": "is", "value": "urgent" }
        ],
        "any": [
          { "field": "type", "operator": "is", "value": "incident" },
          { "field": "type", "operator": "is", "value": "problem" }
        ]
      },
      "execution": {
        "group_by": "status",
        "sort_by": "created_at",
        "sort_order": "asc"
      }
    },
    {
      "id": 1002,
      "title": "📥 Unassigned Support Queue",
      "raw_title": "Unassigned Support Queue",
      "description": "Standard inbound support tickets pending initial triage and assignment. Review customer tier and routing tags before claiming.",
      "active": true,
      "updated_at": "2026-10-02T09:30:00Z",
      "restriction": null,
      "conditions": {
        "all": [
          { "field": "status", "operator": "is", "value": "new" },
          { "field": "assignee_id", "operator": "is", "value": null }
        ],
        "any": []
      },
      "execution": {
        "group_by": "group_id",
        "sort_by": "created_at",
        "sort_order": "asc"
      }
    },
    {
      "id": 1003,
      "title": "👑 VIP & Enterprise Accounts",
      "raw_title": "VIP & Enterprise Accounts",
      "description": "Tickets from Enterprise contract holders (MRR > $5k/mo). Always maintain warm, executive-level tone. Review account notes for custom SLAs.",
      "active": true,
      "updated_at": "2026-10-03T15:20:00Z",
      "restriction": {
        "type": "Group",
        "ids": [401, 402]
      },
      "conditions": {
        "all": [
          { "field": "status", "operator": "less_than", "value": "solved" },
          { "field": "current_tags", "operator": "includes", "value": "vip" }
        ],
        "any": []
      },
      "execution": {
        "group_by": "priority",
        "sort_by": "updated_at",
        "sort_order": "asc"
      }
    },
    {
      "id": 1004,
      "title": "⏳ Pending Customer Verification",
      "raw_title": "Pending Customer Verification",
      "description": "Tickets where our team has replied and we are waiting on logs, screenshots, or confirmation from the user. Auto-solves after 72 hours of inactivity.",
      "active": true,
      "updated_at": "2026-10-04T11:15:00Z",
      "restriction": null,
      "conditions": {
        "all": [
          { "field": "status", "operator": "is", "value": "pending" }
        ],
        "any": []
      },
      "execution": {
        "group_by": "assignee_id",
        "sort_by": "updated_at",
        "sort_order": "desc"
      }
    },
    {
      "id": 1005,
      "title": "🐛 Tier 2 Bug Escalations",
      "raw_title": "Tier 2 Bug Escalations",
      "description": "Reproduced defects assigned to Technical Support Tier 2. Ensure reproduction steps, HAR files, and browser versions are documented before linking to Jira.",
      "active": true,
      "updated_at": "2026-09-28T14:40:00Z",
      "restriction": {
        "type": "Group",
        "ids": [402]
      },
      "conditions": {
        "all": [
          { "field": "status", "operator": "less_than", "value": "solved" },
          { "field": "group_id", "operator": "is", "value": "tier_2" }
        ],
        "any": [
          { "field": "current_tags", "operator": "includes", "value": "bug" },
          { "field": "type", "operator": "is", "value": "problem" }
        ]
      },
      "execution": {
        "group_by": "status",
        "sort_by": "created_at",
        "sort_order": "asc"
      }
    },
    {
      "id": 1006,
      "title": "💳 Billing, Invoices & Refunds",
      "raw_title": "Billing, Invoices & Refunds",
      "description": "Inquiries regarding invoices, credit card charges, refund requests, and tax exemption certificates. Check Stripe account ID before issuing refunds.",
      "active": true,
      "updated_at": "2026-10-02T16:00:00Z",
      "restriction": null,
      "conditions": {
        "all": [
          { "field": "status", "operator": "less_than", "value": "solved" }
        ],
        "any": [
          { "field": "current_tags", "operator": "includes", "value": "billing" },
          { "field": "current_tags", "operator": "includes", "value": "refund" }
        ]
      },
      "execution": {
        "group_by": "priority",
        "sort_by": "created_at",
        "sort_order": "asc"
      }
    },
    {
      "id": 1007,
      "title": "🗄️ Miscellaneous Tickets (Needs Review)",
      "raw_title": "Miscellaneous Tickets (Needs Review)",
      "description": "",
      "active": true,
      "updated_at": "2026-09-15T08:00:00Z",
      "restriction": null,
      "conditions": {
        "all": [
          { "field": "status", "operator": "is", "value": "open" }
        ],
        "any": []
      },
      "execution": {
        "group_by": "status",
        "sort_by": "created_at",
        "sort_order": "desc"
      }
    }
  ]
};

window.MOCK_TICKETS = [
  {
    id: 48921,
    subject: "Production database timeout during checkout - urgent assistance needed",
    status: "open",
    priority: "urgent",
    type: "incident",
    group: { id: 402, name: "Tier 2 Technical Support" },
    assignee: { id: 9812, name: "Alex Chen" },
    tags: ["vip", "incident", "production", "database"]
  },
  {
    id: 48922,
    subject: "Question about invoice #INV-2026-881 duplicate charge",
    status: "open",
    priority: "normal",
    type: "question",
    group: { id: 405, name: "Billing Operations" },
    assignee: { id: 9814, name: "Sarah Miller" },
    tags: ["billing", "refund", "stripe"]
  },
  {
    id: 48923,
    subject: "New user unable to reset password via SSO",
    status: "new",
    priority: "normal",
    type: "question",
    group: null,
    assignee: null,
    tags: ["auth", "sso"]
  }
];
